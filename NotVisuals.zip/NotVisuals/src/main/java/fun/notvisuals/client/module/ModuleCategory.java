package fun.notvisuals.client.module;

public enum ModuleCategory {
    RENDER,
    UTILITY,
    EVENTS,
    COSMETIC,
    CONFIGS
}
