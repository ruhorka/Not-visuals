package fun.notvisuals.client;

import net.fabricmc.api.ClientModInitializer;

public final class NotVisualsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        NotVisuals.LOGGER.info("NotVisuals client initialized.");
        ModuleManager.registerDefaults();
    }
}
