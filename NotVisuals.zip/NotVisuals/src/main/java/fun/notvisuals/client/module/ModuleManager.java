package fun.notvisuals.client;

import fun.notvisuals.client.module.Module;
import fun.notvisuals.client.module.ModuleCategory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean defaultsRegistered;

    private ModuleManager() {}

    public static void register(Module module) {
        MODULES.add(module);
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> getModules(ModuleCategory category) {
        return MODULES.stream().filter(module -> module.getCategory() == category).toList();
    }

    public static void registerDefaults() {
        if (defaultsRegistered) return;
        defaultsRegistered = true;
        // Visual modules will be registered here in the next development stage.
    }
}
