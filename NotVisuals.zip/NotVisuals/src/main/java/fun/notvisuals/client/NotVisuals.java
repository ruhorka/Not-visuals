package fun.notvisuals.client;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NotVisuals implements ModInitializer {
    public static final String MOD_ID = "notvisuals";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("NotVisuals core initialized.");
    }
}
