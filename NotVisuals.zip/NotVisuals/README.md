# NotVisuals

Starter Fabric client mod project for Minecraft **1.21.11** and **Java 21**.

## Current contents
- Fabric mod metadata and client entrypoints
- Initial module base class and categories
- Basic module manager
- Gradle/Loom project configuration

This is a foundation, not the finished client. ClickGUI, visual modules, settings,
HUD, cosmetics and JSON configuration will be implemented in later stages.

## Build
Use Java 21 and Gradle 9.2.1, then run:

```bash
gradle build
```

The built mod JAR will be in `build/libs/`.
