# NotVisuals — Stage 1 foundation

A new client-side Fabric mod project targeting Minecraft **1.21.11**, Java **21**, official Mojang mappings, Fabric Loom and Fabric API.

## Current implementation

- Fabric client entry point and Right Shift keybind.
- Functional ClickGUI shell based on the supplied reference: left category rail, center module cards, right dynamic settings panel.
- Render category currently registers `Custom HitBox` and `Custom Hit Color` configuration modules.
- Module enable/disable state, boolean settings, numeric sliders (0–100), and palette cycling are interactive.
- JSON config loads on client initialization and saves when toggles/settings change and when the GUI closes.
- Custom HitBox settings model includes player/mob/other filters, fill/outline, opacity, line width, colors and Static/Dynamic mode.
- Custom Hit Color settings model includes shared/per-piece armor colors and opacity.

## Important status disclosure

This is a **Stage 1/GUI + configuration foundation**, not the finished client described in the full specification. The two priority modules currently expose and persist their settings, but their in-world rendering hooks are **not implemented yet**. Consequently, enabling them does not currently draw hitboxes or tint armor. The other requested modules, HUD widgets, cosmetics, events, import/export UI, blur and animation polish are also not implemented. No placeholder modules are registered as if they worked.

The project has not been compiled or launched in this environment: Gradle is not installed here and dependency resolution/game launch were not available. Treat the source as an initial development checkpoint, not as a verified installable JAR.

## Build and run

1. Install a Java 21 JDK and IntelliJ IDEA.
2. Open this folder as a Gradle project and allow Gradle to sync dependencies.
3. Run the Gradle task `runClient` to launch the Fabric development client.
4. Run `build` to create the remapped mod JAR under `build/libs/`.
5. Install that JAR into the `mods` folder of a Fabric 1.21.11 installation with Fabric API installed.
6. In game, press **Right Shift** to open ClickGUI.

If Gradle reports an unavailable plugin or dependency, refresh the Gradle project and verify that Fabric Maven and Maven Central are reachable.

## Architecture

- `core` — categories and client foundation
- `module` — module base class and registry
- `module.render` — priority render-module settings
- `gui` — ClickGUI
- `config` — JSON persistence

## Version choices

Minecraft 1.21.11 is the last obfuscated Minecraft release. Fabric's current guidance recommends official Mojang mappings for this line and later migration compatibility. This project therefore uses `loom.officialMojangMappings()` rather than Yarn. See the official [Fabric 1.21.11 notes](https://www.fabricmc.net/2025/12/05/12111.html) and [Loom documentation](https://docs.fabricmc.net/develop/loom/).
