package fun.notvisuals.client.gui;

import fun.notvisuals.client.NotVisualsClient;
import fun.notvisuals.client.core.Category;
import fun.notvisuals.client.module.Module;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class ClickGuiScreen extends Screen {
    private Category category = Category.RENDER;
    private Module selected;
    private String search = "";
    private boolean typingSearch;

    private final List<Hit> hits = new ArrayList<>();

    private record Hit(
            int x,
            int y,
            int w,
            int h,
            Runnable action,
            String sliderKey
    ) {
        Hit(int x, int y, int w, int h, Runnable action) {
            this(x, y, w, h, action, null);
        }

        boolean contains(double mx, double my) {
            return mx >= x && mx <= x + w
                    && my >= y && my <= y + h;
        }
    }

    public ClickGuiScreen() {
        super(Component.literal("NotVisuals"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        int panelW = Math.min(760, width - 40);
        int panelH = Math.min(430, height - 40);

        int x = (width - panelW) / 2;
        int y = (height - panelH) / 2;

        hits.clear();

        g.fill(0, 0, width, height, 0x99070A0D);
        g.fill(x, y, x + panelW, y + panelH, 0xF0181B20);
        g.fill(x, y, x + 112, y + panelH, 0xF01D2025);
        g.fill(x + 112, y, x + panelW - 194, y + panelH, 0xF01A1D22);
        g.fill(x + panelW - 194, y, x + panelW, y + panelH, 0xF0212429);

        g.drawString(font, "NV", x + 16, y + 16, 0xFFFFB58A, false);
        g.drawString(font, "NOTVISUALS", x + 39, y + 17, 0xFFE6E8EB, false);

        int cy = y + 55;

        for (Category c : Category.values()) {
            int yy = cy;
            boolean active = c == category;

            g.fill(
                    x + 8,
                    yy - 5,
                    x + 104,
                    yy + 17,
                    active ? 0x44F2A477 : 0x00111111
            );

            g.drawString(
                    font,
                    c.title(),
                    x + 19,
                    yy,
                    active ? 0xFFFFB58A : 0xFFB7BCC4,
                    false
            );

            hits.add(new Hit(
                    x + 8,
                    yy - 5,
                    96,
                    22,
                    () -> {
                        category = c;
                        selected = null;
                    }
            ));

            cy += 31;
        }

        g.drawString(font, "PROFILE", x + 15, y + panelH - 55, 0xFF777E88, false);
        g.drawString(font, "Local player", x + 15, y + panelH - 39, 0xFFE6E8EB, false);
        g.drawString(font, "NotVisuals  •  local", x + 15, y + panelH - 24, 0xFF8D949E, false);

        int cx = x + 128;
        int right = x + panelW - 206;

        g.drawString(font, category.title(), cx, y + 17, 0xFFF1F2F4, false);

        g.fill(cx, y + 35, right - 12, y + 57, 0xFF292D33);

        g.drawString(
                font,
                search.isEmpty() ? "Search modules..." : search,
                cx + 8,
                y + 42,
                0xFF9EA5AF,
                false
        );

        hits.add(new Hit(
                cx,
                y + 35,
                right - cx - 12,
                22,
                () -> typingSearch = true
        ));

        int cardW = Math.max(120, (right - cx - 22) / 2);
        int index = 0;

        for (Module m : NotVisualsClient.MODULES.in(category)) {
            if (!m.name().toLowerCase().contains(search.toLowerCase())) {
                continue;
            }

            int col = index % 2;
            int row = index / 2;

            int bx = cx + col * (cardW + 10);
            int by = y + 68 + row * 64;

            g.fill(
                    bx,
                    by,
                    bx + cardW,
                    by + 56,
                    selected == m ? 0xFF343941 : 0xFF272B31
            );

            g.drawString(font, m.name(), bx + 9, by + 8, 0xFFE9EBEF, false);

            g.drawString(
                    font,
                    truncate(m.description(), 31),
                    bx + 9,
                    by + 22,
                    0xFF969DA7,
                    false
            );

            g.fill(
                    bx + cardW - 36,
                    by + 34,
                    bx + cardW - 10,
                    by + 47,
                    m.enabled() ? 0xFFECA77F : 0xFF555B64
            );

            g.drawString(
                    font,
                    m.enabled() ? "ON" : "OFF",
                    bx + cardW - 32,
                    by + 37,
                    0xFF101216,
                    false
            );

            hits.add(new Hit(
                    bx,
                    by,
                    cardW - 42,
                    56,
                    () -> selected = m
            ));

            hits.add(new Hit(
                    bx + cardW - 42,
                    by + 28,
                    42,
                    28,
                    () -> {
                        m.toggle();
                        NotVisualsClient.CONFIG.save(NotVisualsClient.MODULES);
                    }
            ));

            index++;
        }

        if (index == 0) {
            g.drawString(
                    font,
                    "No modules in this category yet",
                    cx + 4,
                    y + 78,
                    0xFF8D949E,
                    false
            );
        }

        if (selected != null) {
            renderSettings(g, x + panelW - 182, y, panelH);
        }

        super.render(g, mouseX, mouseY, delta);
    }

    private void renderSettings(GuiGraphics g, int x, int y, int panelH) {
        g.drawString(font, "SETTINGS", x + 12, y + 17, 0xFFFFB58A, false);
        g.drawString(font, selected.name(), x + 12, y + 38, 0xFFE9EBEF, false);

        int yy = y + 64;

        for (var entry : selected.flags().entrySet()) {
            String key = entry.getKey();
            boolean value = entry.getValue();
            int row = yy;

            g.drawString(font, key, x + 12, row, 0xFFBFC4CC, false);

            g.fill(
                    x + 132,
                    row - 3,
                    x + 164,
                    row + 9,
                    value ? 0xFFECA77F : 0xFF555B64
            );

            g.drawString(
                    font,
                    value ? "ON" : "OFF",
                    x + 137,
                    row - 1,
                    0xFF15171A,
                    false
            );

            hits.add(new Hit(
                    x + 126,
                    row - 7,
                    48,
                    22,
                    () -> {
                        selected.flags().put(key, !selected.flags().get(key));
                        NotVisualsClient.CONFIG.save(NotVisualsClient.MODULES);
                    }
            ));

            yy += 23;
        }

        for (var entry : selected.numbers().entrySet()) {
            String key = entry.getKey();
            double value = entry.getValue();
            int row = yy;

            g.drawString(
                    font,
                    key + ": " + String.format("%.1f", value),
                    x + 12,
                    row,
                    0xFFBFC4CC,
                    false
            );

            g.fill(x + 12, row + 12, x + 164, row + 16, 0xFF555B64);

            int knob = x + 12
                    + (int) (Math.max(0, Math.min(100, value)) / 100.0 * 152);

            g.fill(knob - 2, row + 9, knob + 3, row + 19, 0xFFFFB58A);

            hits.add(new Hit(
                    x + 10,
                    row + 7,
                    158,
                    16,
                    () -> {},
                    key
            ));

            yy += 35;
        }

        for (var entry : selected.colors().entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            int row = yy;

            g.drawString(font, key, x + 12, row, 0xFFBFC4CC, false);
            g.drawString(font, value, x + 12, row + 11, 0xFFFFB58A, false);

            hits.add(new Hit(
                    x + 10,
                    row - 3,
                    158,
                    28,
                    () -> {
                        String[] palette = {
                                "#F2A477",
                                "#8CCBFF",
                                "#A8E6A1",
                                "#D7A8FF",
                                "#FFFFFF"
                        };

                        int i = java.util.Arrays.asList(palette)
                                .indexOf(selected.colors().get(key));

                        selected.colors().put(
                                key,
                                palette[(i + 1) % palette.length]
                        );

                        NotVisualsClient.CONFIG.save(NotVisualsClient.MODULES);
                    }
            ));

            yy += 31;
        }

        if (yy > y + panelH - 18) {
            g.drawString(
                    font,
                    "Scroll settings in next iteration",
                    x + 12,
                    y + panelH - 17,
                    0xFF747B85,
                    false
            );
        }
    }

    private static String truncate(String s, int n) {
        return s.length() > n ? s.substring(0, n - 1) + "…" : s;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x();
        double my = event.y();

        for (int i = hits.size() - 1; i >= 0; i--) {
            if (hits.get(i).contains(mx, my)) {
                Hit hit = hits.get(i);

                if (hit.sliderKey() != null && selected != null) {
                    double v = Math.max(
                            0,
                            Math.min(100, (mx - hit.x()) / (double) hit.w() * 100.0)
                    );

                    selected.numbers().put(hit.sliderKey(), v);
                    NotVisualsClient.CONFIG.save(NotVisualsClient.MODULES);
                } else {
                    hit.action().run();
                }

                return true;
            }
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int codepoint = event.codepoint();

        if (typingSearch && !Character.isISOControl(codepoint)) {
            search += new String(Character.toChars(codepoint));
            return true;
        }

        return super.charTyped(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();

        if (key == 256) {
            onClose();
            return true;
        }

        if (key == 259 && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            return true;
        }

        if (key == 257) {
            typingSearch = !typingSearch;
            return true;
        }

        if (key == 258) {
            typingSearch = true;
            return true;
        }

        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        NotVisualsClient.CONFIG.save(NotVisualsClient.MODULES);
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}