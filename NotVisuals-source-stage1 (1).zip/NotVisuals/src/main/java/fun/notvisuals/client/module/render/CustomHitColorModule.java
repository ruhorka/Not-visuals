package fun.notvisuals.client.module.render;

import fun.notvisuals.client.core.Category;
import fun.notvisuals.client.module.Module;

public final class CustomHitColorModule extends Module {
    public CustomHitColorModule() {
        super("Custom Hit Color", "Armor tint configuration. Original armor textures should remain visible.", Category.RENDER);
        flag("Use one color", true); flag("Helmet", true); flag("Chestplate", true);
        flag("Leggings", true); flag("Boots", true);
        number("Opacity", 45);
        color("Color", "#F2A477"); color("Helmet color", "#F2A477");
        color("Chestplate color", "#F2A477"); color("Leggings color", "#F2A477"); color("Boots color", "#F2A477");
    }
}
