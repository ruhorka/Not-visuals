
package fun.notvisuals.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import fun.notvisuals.client.NotVisualsClient;
import fun.notvisuals.client.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class HitBoxRenderer {
    private HitBoxRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(HitBoxRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        Module module = NotVisualsClient.MODULES.find("Custom HitBox");

        if (module == null || !module.enabled()) return;
        if (!module.flags().getOrDefault("Outline", true)) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        Vec3 camera = mc.gameRenderer.getMainCamera().position();
        PoseStack matrices = context.matrices();

        int color = parseColor(
            module.colors().getOrDefault("Outline color", "#FFB58A")
        );

        float alpha = (float) (
            module.numbers().getOrDefault("Outline opacity", 100.0) / 100.0
        );

        alpha = Math.max(0.0f, Math.min(1.0f, alpha));

        float red = ((color >> 16) & 255) / 255.0f;
        float green = ((color >> 8) & 255) / 255.0f;
        float blue = (color & 255) / 255.0f;

        matrices.pushPose();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumer vertices =
            context.consumers().getBuffer(RenderType.lines());

        PoseStack.Pose pose = matrices.last();

        for (Entity entity : mc.level.entitiesForRendering()) {
            if (entity == mc.player && !module.flags().getOrDefault("Players", true)) {
                continue;
            }

            if (entity instanceof Player &&
                !module.flags().getOrDefault("Players", true)) continue;

            if (entity instanceof Mob &&
                !module.flags().getOrDefault("Mobs", false)) continue;

            if (!(entity instanceof Player) && !(entity instanceof Mob) &&
                !module.flags().getOrDefault("Other entities", false)) continue;

            AABB box = entity.getBoundingBox().inflate(0.002);

            drawBox(
                vertices, pose, box,
                red, green, blue, alpha
            );
        }

        matrices.popPose();
    }

    private static void drawBox(
        VertexConsumer v,
        PoseStack.Pose pose,
        AABB b,
        float r, float g, float blue, float a
    ) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ;
        double x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;

        line(v, pose, x1,y1,z1, x2,y1,z1,r,g,blue,a);
        line(v, pose, x2,y1,z1, x2,y1,z2,r,g,blue,a);
        line(v, pose, x2,y1,z2, x1,y1,z2,r,g,blue,a);
        line(v, pose, x1,y1,z2, x1,y1,z1,r,g,blue,a);

        line(v, pose, x1,y2,z1, x2,y2,z1,r,g,blue,a);
        line(v, pose, x2,y2,z1, x2,y2,z2,r,g,blue,a);
        line(v, pose, x2,y2,z2, x1,y2,z2,r,g,blue,a);
        line(v, pose, x1,y2,z2, x1,y2,z1,r,g,blue,a);

        line(v, pose, x1,y1,z1, x1,y2,z1,r,g,blue,a);
        line(v, pose, x2,y1,z1, x2,y2,z1,r,g,blue,a);
        line(v, pose, x2,y1,z2, x2,y2,z2,r,g,blue,a);
        line(v, pose, x1,y1,z2, x1,y2,z2,r,g,blue,a);
    }

    private static void line(
        VertexConsumer v,
        PoseStack.Pose pose,
        double x1, double y1, double z1,
        double x2, double y2, double z2,
        float r, float g, float b, float a
    ) {
        v.addVertex(pose, (float)x1, (float)y1, (float)z1)
            .setColor(r,g,b,a)
            .setNormal(pose, 0,1,0);

        v.addVertex(pose, (float)x2, (float)y2, (float)z2)
            .setColor(r,g,b,a)
            .setNormal(pose, 0,1,0);
    }

    private static int parseColor(String hex) {
        try {
            return Integer.parseInt(hex.replace("#", ""), 16);
        } catch (Exception e) {
            return 0xFFB58A;
        }
    }
}
