package fun.notvisuals.client.core;

public enum Category {
    RENDER("Render"), UTILITY("Utility"), EVENTS("Events"), COSMETIC("Cosmetic"), CONFIGS("Configs");
    private final String title;
    Category(String title) { this.title = title; }
    public String title() { return title; }
}
