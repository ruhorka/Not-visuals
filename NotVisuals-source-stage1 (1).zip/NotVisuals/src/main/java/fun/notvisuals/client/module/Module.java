package fun.notvisuals.client.module;

import fun.notvisuals.client.core.Category;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class Module {
    private final String name, description;
    private final Category category;
    private boolean enabled;
    private final Map<String, Double> numbers = new LinkedHashMap<>();
    private final Map<String, Boolean> flags = new LinkedHashMap<>();
    private final Map<String, String> colors = new LinkedHashMap<>();

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }
    public String name() { return name; }
    public String description() { return description; }
    public Category category() { return category; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }
    public void toggle() { setEnabled(!enabled); }
    protected void onEnable() {}
    protected void onDisable() {}
    protected void number(String key, double value) { numbers.put(key, value); }
    protected void flag(String key, boolean value) { flags.put(key, value); }
    protected void color(String key, String value) { colors.put(key, value); }
    public Map<String, Double> numbers() { return numbers; }
    public Map<String, Boolean> flags() { return flags; }
    public Map<String, String> colors() { return colors; }
}
