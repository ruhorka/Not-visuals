package fun.notvisuals.client.module.render;

import fun.notvisuals.client.core.Category;
import fun.notvisuals.client.module.Module;

public final class CustomHitBoxModule extends Module {
    public CustomHitBoxModule() {
        super("Custom HitBox", "Visual entity-box styling. Collision sizes are never changed.", Category.RENDER);
        flag("Players", true); flag("Mobs", false); flag("Other entities", false);
        flag("Fill", true); flag("Outline", true);
        number("Fill opacity", 24); number("Outline opacity", 100); number("Line width", 1.5);
        color("Fill color", "#F2A477"); color("Outline color", "#FFB58A");
        color("Mode", "Static");
    }
}
