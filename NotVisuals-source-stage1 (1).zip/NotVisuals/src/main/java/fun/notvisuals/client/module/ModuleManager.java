package fun.notvisuals.client.module;

import fun.notvisuals.client.core.Category;
import fun.notvisuals.client.module.render.CustomHitBoxModule;
import fun.notvisuals.client.module.render.CustomHitColorModule;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    public ModuleManager() { register(new CustomHitBoxModule()); register(new CustomHitColorModule()); }
    public void register(Module module) { modules.add(module); }
    public List<Module> all() { return List.copyOf(modules); }
    public List<Module> in(Category category) { return modules.stream().filter(m -> m.category() == category).toList(); }
    public Module find(String name) { return modules.stream().filter(m -> m.name().equals(name)).findFirst().orElse(null); }
}
