package fun.notvisuals.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import fun.notvisuals.client.module.Module;
import fun.notvisuals.client.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("notvisuals.json");

    public void save(ModuleManager manager) {
        JsonObject root = new JsonObject();
        for (Module module : manager.all()) {
            JsonObject item = new JsonObject();
            item.addProperty("enabled", module.enabled());
            JsonObject numbers = new JsonObject(); module.numbers().forEach(numbers::addProperty);
            JsonObject flags = new JsonObject(); module.flags().forEach(flags::addProperty);
            JsonObject colors = new JsonObject(); module.colors().forEach(colors::addProperty);
            item.add("numbers", numbers); item.add("flags", flags); item.add("colors", colors);
            root.add(module.name(), item);
        }
        try { Files.createDirectories(file.getParent()); Files.writeString(file, GSON.toJson(root)); }
        catch (IOException e) { System.err.println("[NotVisuals] Config save failed: " + e.getMessage()); }
    }

    public void load(ModuleManager manager) {
        if (!Files.exists(file)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(file), JsonObject.class);
            if (root == null) return;
            for (Module module : manager.all()) {
                if (!root.has(module.name())) continue;
                JsonObject item = root.getAsJsonObject(module.name());
                if (item.has("enabled")) module.setEnabled(item.get("enabled").getAsBoolean());
                applyNumbers(item, "numbers", module.numbers());
                applyFlags(item, "flags", module.flags());
                applyStrings(item, "colors", module.colors());
            }
        } catch (Exception e) { System.err.println("[NotVisuals] Config load failed: " + e.getMessage()); }
    }
    private static void applyNumbers(JsonObject item, String key, java.util.Map<String, Double> target) {
        if (item.has(key)) item.getAsJsonObject(key).entrySet().forEach(e -> { if (target.containsKey(e.getKey())) target.put(e.getKey(), e.getValue().getAsDouble()); });
    }
    private static void applyFlags(JsonObject item, String key, java.util.Map<String, Boolean> target) {
        if (item.has(key)) item.getAsJsonObject(key).entrySet().forEach(e -> { if (target.containsKey(e.getKey())) target.put(e.getKey(), e.getValue().getAsBoolean()); });
    }
    private static void applyStrings(JsonObject item, String key, java.util.Map<String, String> target) {
        if (item.has(key)) item.getAsJsonObject(key).entrySet().forEach(e -> { if (target.containsKey(e.getKey())) target.put(e.getKey(), e.getValue().getAsString()); });
    }
}
