package fun.notvisuals.client;

import fun.notvisuals.client.config.ConfigManager;
import fun.notvisuals.client.core.Category;
import fun.notvisuals.client.gui.ClickGuiScreen;
import fun.notvisuals.client.module.ModuleManager;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class NotVisualsClient implements ClientModInitializer {

    public static final ModuleManager MODULES = new ModuleManager();
    public static final ConfigManager CONFIG = new ConfigManager();

    private static KeyMapping openGui;

    private static final KeyMapping.Category NOTVISUALS_CATEGORY =
            KeyMapping.Category.register(
                    Identifier.fromNamespaceAndPath("notvisuals", "clickgui")
            );

    @Override
    public void onInitializeClient() {
        CONFIG.load(MODULES);

        openGui = KeyBindingHelper.registerKeyBinding(
                new KeyMapping(
                        "key.notvisuals.clickgui",
                        InputConstants.Type.KEYSYM,
                        GLFW.GLFW_KEY_RIGHT_SHIFT,
                        NOTVISUALS_CATEGORY
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.consumeClick()) {
                client.setScreen(new ClickGuiScreen());
            }
        });
    }
}