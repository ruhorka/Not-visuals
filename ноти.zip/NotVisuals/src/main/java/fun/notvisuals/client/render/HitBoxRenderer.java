package fun.notvisuals.client.render;

import fun.notvisuals.client.NotVisualsClient;
import fun.notvisuals.client.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

public final class HitBoxRenderer {

    private HitBoxRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(
            HitBoxRenderer::render
        );
    }

    private static void render(WorldRenderContext context) {
        Module module = NotVisualsClient.MODULES.find("Custom HitBox");

        if (module == null || !module.enabled()) {
            return;
        }

        // Временно отключена отрисовка:
        // предотвращает вылет из-за отсутствующего LineWidth.
    }
}